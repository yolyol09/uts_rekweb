ALTER TABLE `#__spsimpleportfolio_items` ADD `client_avatar` text NOT NULL AFTER `client`;
ALTER TABLE `#__spsimpleportfolio_items` ADD `thumbnail` text NOT NULL AFTER `image`;