<?php
/**
* @package     SP Simple Portfolio
*
* @copyright   Copyright (C) 2010 - 2022 JoomShaper. All rights reserved.
* @license     GNU General Public License version 2 or later.
*/

use Joomla\CMS\MVC\Controller\BaseController;


class SpsimpleportfolioController extends BaseController {}
